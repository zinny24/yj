package ch03;

import java.util.Scanner;

public class Code03_10 {
	public static void main(String[] args) {
		//스캐너를 통해서 1 ~ 100 사이의 점수를 입력 받은 후
		//(입력한 점수가) 70이상일 때 결과를 표시하시오.
		// new 객체명 - 생성자(객체 초기화)
		Scanner s = new Scanner(System.in);
		
		System.out.println("1 ~ 100 점수를 입력하시오.");
		int score = s.nextInt();
		
		System.out.println(   score >= 70      );
		
		s.close();
	}

}



