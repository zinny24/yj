package com.example.demo.controller;

import com.example.demo.entity.Board;
import com.example.demo.entity.User;
import com.example.demo.service.BoardService;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.io.Resource;
import org.springframework.core.io.UrlResource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.net.MalformedURLException;
import java.nio.file.Path;
import java.nio.file.Paths;

@Controller
@RequiredArgsConstructor
public class BoardController {

    private final BoardService boardService;

    @Value("${file.upload.dir}")  // 파일을 저장할 디렉토리 경로 (application.properties에서 설정)
    private String uploadDir;

    // 게시글 목록
    @GetMapping("/board")
    public String board(Model model) {
        model.addAttribute("posts", boardService.getAllPosts());
        return "home"; // templates/board.html
    }

    // 글쓰기 폼
    @GetMapping("/board/write")
    public String writeForm(Model model) {
        model.addAttribute("board", new Board());
        return "board/write"; // templates/board/write.html
    }

    // 글 작성 처리
    @PostMapping("/board")
    public String write(@ModelAttribute Board board,
                        @RequestParam(value = "files", required = false) MultipartFile[] files, // 파일 업로드
                        @SessionAttribute(name = "loginUser", required = false) User user) {

        if (user == null) {
            return "redirect:/login"; // 로그인하지 않으면 로그인 페이지로 리다이렉트
        }

        board.setWriter(user.getUsername()); // 로그인한 사용자 이름으로 게시글 작성자 설정

        // 새 글 작성 시 parent_id는 null이어야 합니다.
        board.setParent(null);

        // 파일 첨부가 없을 경우 saveFiles 호출을 하지 않음
        if (files != null && files.length > 0) {
            boardService.writePost(board, files); // 파일이 있을 경우만 처리
        } else {
            boardService.writePost(board, new MultipartFile[0]); // 파일이 없으면 빈 배열로 처리
        }

        return "redirect:/"; // 게시글 목록으로 리다이렉트
    }



    // 게시글 보기
    @GetMapping("/board/view/{id}")
    public String viewPost(@PathVariable Long id, Model model) {
        Board post = boardService.getPost(id); // 게시글 조회
        model.addAttribute("post", post);
        return "board/view"; // templates/board/view.html
    }

    // 답글 폼
    @GetMapping("/board/reply/{id}")
    public String replyForm(@PathVariable Long id, Model model) {
        Board parent = boardService.getPost(id); // 부모 게시글 조회
        model.addAttribute("parent", parent);
        model.addAttribute("reply", new Board()); // 새 답글 객체
        return "board/reply-form"; // templates/board/reply-form.html
    }

    // 답글 처리
    @PostMapping("/board/reply/{id}")
    public String reply(@PathVariable Long id,
                        @ModelAttribute("reply") Board reply,
                        @RequestParam(value = "files", required = false) MultipartFile[] files, // 파일 업로드
                        @SessionAttribute(name = "loginUser", required = false) User user) {

        if (user == null) {
            return "redirect:/login"; // 로그인하지 않으면 로그인 페이지로 리다이렉트
        }

        reply.setId(null); // 새 글이므로 ID는 null 처리 (새 게시글 생성)
        reply.setWriter(user.getUsername()); // 답글 작성자 설정

        // 부모 게시글 정보 설정
        Board parent = boardService.getPost(id);
        reply.setParent(parent); // 부모 게시글 설정
        reply.setGroupId(parent.getGroupId()); // 부모 게시글의 groupId
        reply.setDepth(parent.getDepth() + 1); // 부모 게시글의 depth + 1
        reply.setStep(parent.getStep() + 1); // 부모 게시글의 step + 1

        // 답글 저장
        boardService.replyToPost(id, reply, files); // 파일 포함 답글 작성

        return "redirect:/"; // 게시글 목록으로 리다이렉트
    }

    @GetMapping("/board/download/{fileName}")
    public ResponseEntity<Resource> downloadFile(@PathVariable String fileName) throws MalformedURLException {
        // 업로드된 파일의 경로로 파일을 찾음 (상대 경로)
        Path filePath = Paths.get(uploadDir).resolve(fileName);
        Resource resource = new UrlResource(filePath.toUri());

        if (resource.exists()) {
            // 파일이 존재하면 다운로드 처리
            String contentDisposition = "attachment; filename=\"" + fileName + "\"";
            return ResponseEntity.ok()
                    .header(HttpHeaders.CONTENT_DISPOSITION, contentDisposition)
                    .body(resource);
        } else {
            return ResponseEntity.notFound().build(); // 파일이 없으면 404 반환
        }
    }



}
