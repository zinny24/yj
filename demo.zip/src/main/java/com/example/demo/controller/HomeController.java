package com.example.demo.controller;

import com.example.demo.service.BoardService;
import com.example.demo.entity.Board;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

import java.util.List;

@Controller
@RequiredArgsConstructor
public class HomeController {

    private final BoardService boardService;

    @GetMapping("/")
    public String home(Model model) {
        List<Board> posts = boardService.getAllPosts();
        model.addAttribute("posts", posts);

        return "home";
    }
}
