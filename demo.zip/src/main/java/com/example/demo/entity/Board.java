package com.example.demo.entity;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.hibernate.annotations.CreationTimestamp;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

@Entity
@Table(name = "board")
@Getter
@Setter
@NoArgsConstructor
public class Board {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String title;

    @Lob
    private String content;

    private String writer;

    @CreationTimestamp
    @Column(updatable = false)
    private LocalDateTime createdAt;

    private Integer groupId = 0; // 기본값 설정

    private Integer step = 0;  // 기본값 0으로 설정

    private int depth = 0;

    @ManyToOne
    @JoinColumn(name = "parent_id")
    private Board parent;

    // 첨부파일 목록을 저장하는 필드 추가
    @ElementCollection
    @CollectionTable(name = "board_attachments", joinColumns = @JoinColumn(name = "board_id"))
    @Column(name = "attachment")
    private List<String> attachments = new ArrayList<>();

    // 게시글 생성 시 기본값을 설정하는 메서드
    public void setDefaultValues() {
        if (this.step == null) {
            this.step = 0;  // step 값이 null일 경우 기본값 0으로 설정
        }
        if (this.depth == 0) {
            this.depth = 0; // 기본 depth는 0으로 설정
        }
    }

    // 첨부파일 추가 메서드
    public void addAttachment(String filePath) {
        if (filePath != null && !filePath.isEmpty()) {
            if (this.attachments == null) {
                this.attachments = new ArrayList<>();
            }
            this.attachments.add(filePath);
        }
    }

    // 여러 첨부파일을 한 번에 추가하는 메서드
    public void addAttachments(List<String> filePaths) {
        if (filePaths != null && !filePaths.isEmpty()) {
            if (this.attachments == null) {
                this.attachments = new ArrayList<>();
            }
            this.attachments.addAll(filePaths);
        }
    }

    // 첨부파일 삭제 메서드
    public void removeAttachment(String filePath) {
        if (this.attachments != null && !this.attachments.isEmpty()) {
            this.attachments.remove(filePath);
        }
    }

    // 첨부파일이 존재하는지 확인하는 메서드
    public boolean hasAttachment(String filePath) {
        return this.attachments != null && this.attachments.contains(filePath);
    }
}
