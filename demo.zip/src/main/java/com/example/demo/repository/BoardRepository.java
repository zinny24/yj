package com.example.demo.repository;

import com.example.demo.entity.Board;
import jakarta.transaction.Transactional;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface BoardRepository extends JpaRepository<Board, Long> {

    // 그룹, 스텝 순으로 정렬
    @Query("SELECT b FROM Board b ORDER BY b.groupId DESC, b.step ASC")
    List<Board> findAllByOrderByGroupIdDescStepAsc();

    // 최대 groupId 조회
    @Query("SELECT MAX(b.groupId) FROM Board b")
    Integer findMaxGroupId();

    @Modifying
    @Transactional
    @Query("UPDATE Board b SET b.step = b.step + 1 WHERE b.groupId = :groupId AND b.step >= :step")
    void updateStepsAfter(int groupId, int step);
}
