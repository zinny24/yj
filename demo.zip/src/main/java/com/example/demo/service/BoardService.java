package com.example.demo.service;

import com.example.demo.entity.Board;
import com.example.demo.repository.BoardRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.List;

@Service
@RequiredArgsConstructor
public class BoardService {

    private final BoardRepository boardRepository;

    @Value("${file.upload.dir}")  // 파일을 저장할 디렉토리 경로 (application.properties에서 설정)
    private String uploadDir;

    // 모든 게시글 조회
    public List<Board> getAllPosts() {
        return boardRepository.findAllByOrderByGroupIdDescStepAsc(); // 게시글을 그룹ID 내림차순, step 오름차순으로 정렬하여 조회
    }

    // 게시글 작성 처리
    public void writePost(Board board, MultipartFile[] files) {
        // 게시글 기본값 설정
        if (board.getGroupId() == 0) {
            Integer maxGroupId = boardRepository.findMaxGroupId();
            board.setGroupId(maxGroupId == null ? 1 : maxGroupId + 1); // 최초에는 1로 시작
        }

        board.setDefaultValues(); // 게시글 기본값 설정

        // 파일이 선택된 경우에만 파일 처리
        if (files != null && files.length > 0) {
            saveFiles(board, files); // 파일 포함 게시글 작성
        }

        boardRepository.save(board); // 게시글 저장
    }


    // 답글 처리
    public void replyToPost(Long parentId, Board reply, MultipartFile[] files) {
        Board parent = boardRepository.findById(parentId)
                .orElseThrow(() -> new RuntimeException("부모 게시글 없음"));

        // 부모 게시글의 그룹 정보와 깊이를 이어받아 답글 설정
        int newStep = parent.getStep() + 1;
        boardRepository.updateStepsAfter(parent.getGroupId(), newStep); // 부모 그룹의 step을 업데이트

        reply.setGroupId(parent.getGroupId()); // 부모의 groupId 사용
        reply.setDepth(parent.getDepth() + 1); // 부모의 depth + 1
        reply.setStep(newStep); // 부모의 step + 1
        reply.setParent(parent); // 부모 게시글 설정

        reply.setDefaultValues(); // 답글 기본값 설정

        // 파일 처리
        saveFiles(reply, files);

        boardRepository.save(reply); // 답글 저장
    }

    // 게시글 조회
    public Board getPost(Long id) {
        return boardRepository.findById(id).orElse(null); // 게시글 조회
    }

    // 파일 저장 처리
    private void saveFiles(Board board, MultipartFile[] files) {
        // 파일이 첨부되지 않으면 아무 작업도 하지 않음
        if (files == null || files.length == 0) {
            return;
        }

        // 파일이 첨부된 경우에만 처리
        for (MultipartFile file : files) {
            if (file.isEmpty()) {
                continue;  // 빈 파일은 건너뛰기
            }

            try {
                // 고유 파일 이름 설정 (timestamp + 원본 파일명)
                String fileName = System.currentTimeMillis() + "_" + file.getOriginalFilename();

                // 업로드할 디렉토리 경로 설정
                Path uploadPath = Paths.get(uploadDir);
                if (!Files.exists(uploadPath)) {
                    Files.createDirectories(uploadPath); // 디렉토리가 없으면 생성
                }

                // 파일을 저장할 경로 설정
                Path filePath = uploadPath.resolve(fileName);

                // 파일 저장
                file.transferTo(filePath.toFile());

                // 파일 경로를 게시글에 추가
                board.addAttachment(fileName); // 또는 filePath.toString()을 저장할 수 있음
            } catch (IOException e) {
                e.printStackTrace();
                throw new RuntimeException("파일 저장에 실패했습니다.");
            }
        }
    }



}
