package com.example.demo.service;

import com.example.demo.entity.User;
import com.example.demo.repository.UserRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
@RequiredArgsConstructor
public class UserService {

    private final UserRepository userRepository;

    public void register(String userid, String passwd, String username, String role) {
        if (userRepository.findByUserid(userid).isPresent()) {
            throw new RuntimeException("이미 존재하는 ID입니다.");
        }

        User user = new User();
        user.setUserid(userid);
        user.setPasswd(passwd);
        user.setUsername(username);
        user.setRole(role);
        userRepository.save(user);
    }


    public User login(String userid, String passwd) {
        return userRepository.findByUserid(userid)
                .filter(user -> user.getPasswd().equals(passwd))
                .orElse(null);
    }

    public List<User> findAllUsers() {
        return userRepository.findAll();
    }

    public Optional<User> findById(Long id) {
        return userRepository.findById(id);
    }

    public void save(User user) {
        userRepository.save(user);
    }

    public Page<User> findAllPaged(int page, int size) {
        Pageable pageable = PageRequest.of(page, size, Sort.by(Sort.Direction.DESC, "createdAt"));
        return userRepository.findAllByOrderByCreatedAtDesc(pageable);
    }

    public void deleteUser(Long id) {
        userRepository.deleteById(id);
    }



}
