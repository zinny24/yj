package com.example.grp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class GrpApplication {

	public static void main(String[] args) {
		SpringApplication.run(GrpApplication.class, args);
	}

}
