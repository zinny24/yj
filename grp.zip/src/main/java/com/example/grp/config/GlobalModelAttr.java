package com.example.grp.config;

import com.example.grp.entity.SiteSettings;
import com.example.grp.rep.AdminRep;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ModelAttribute;

import java.util.ArrayList;
import java.util.List;

@ControllerAdvice
public class GlobalModelAttr {

    private final AdminRep adminRep;

    public GlobalModelAttr(AdminRep adminRep) {
        this.adminRep = adminRep;
    }

    @ModelAttribute("siteIntro") //html에서 사용할 이름
    public String siteIntro() {
        return adminRep.findFirstByOrderByIdDesc()
                .map(SiteSettings::getIntro)
                .orElse("웹사이트");
    }

    @ModelAttribute("siteTitle") //html에서 사용할 이름
    public String siteTitle() {
        return adminRep.findFirstByOrderByIdDesc()
                .map(SiteSettings::getTitle)
                .orElse("양정인력개발센터");
    }

    @ModelAttribute("siteMenus")
    public List<String> siteMenus() {
        List<String> menus = new ArrayList<>();

        adminRep.findFirstByOrderByIdDesc()
                .ifPresent(siteSettings -> {
                    String[] menuArr = siteSettings.getMenu().split(",");

                    for(String menu : menuArr) {
                        menus.add( menu.trim() );
                    }
                });

        return menus;
    }

    @ModelAttribute("siteMenusEng")
    public List<String> siteMenusEng() {
        List<String> menuLinks = new ArrayList<>();

        adminRep.findFirstByOrderByIdDesc()
                .ifPresent(siteSettings -> {
                    String[] menuEngArr = siteSettings.getMenuEng().split(",");

                    for(String menuEng : menuEngArr) {
                        menuLinks.add( "/" + menuEng.trim() );
                    }
                });

        return menuLinks;
    }

}
