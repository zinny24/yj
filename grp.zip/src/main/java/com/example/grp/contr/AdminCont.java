package com.example.grp.contr;

import com.example.grp.entity.SiteSettings;
import com.example.grp.entity.User;
import com.example.grp.rep.AdminRep;
import com.example.grp.rep.AuthRep;
import com.example.grp.srv.AdminSrv;
import jakarta.servlet.http.HttpSession;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;
import java.util.Optional;

@Controller
@RequestMapping("/admin")
public class AdminCont {

    @Autowired
    private final AdminSrv adminSrv;

    @Autowired
    private AuthRep authRep;

    public AdminCont(AdminSrv adminSrv) {
        this.adminSrv = adminSrv;
    }

    @GetMapping
    public String adminPage(Model model) {

        List<User> users = authRep.findAll();


        SiteSettings ss = adminSrv.getFindLatest();
        if( ss == null ) {
            ss = new SiteSettings();
        }

        model.addAttribute("users", users);
        model.addAttribute("siteSettings", ss);
        return "admin/admin";
    }

    @PostMapping("/save-site")
    public ResponseEntity<String> saveSite(
            @RequestBody SiteSettings siteSettings) {


        SiteSettings ss = adminSrv.findLatest()
                .map(existing -> {
                    existing.setTitle(  siteSettings.getTitle() );
                    existing.setMenu(  siteSettings.getMenu() );
                    existing.setMenuEng(  siteSettings.getMenuEng() );
                    existing.setIntro(  siteSettings.getIntro() );
                    return existing;

                }).orElse(siteSettings);

            adminSrv.siteSave(ss);
        return ResponseEntity.ok("success");
    }

    @PostMapping("/update-role")
    @ResponseBody
    public ResponseEntity<?> updateUserRole(
            @RequestBody Map<String, Object> body,
            HttpSession session) {

        User u = (User) session.getAttribute("loginUser");
        if( u == null || !u.getRole().equals("admin") ) {
            return ResponseEntity.status(HttpStatus.FORBIDDEN).build();
        }

        Long id = Long.valueOf(body.get("id").toString());
        String newRole = body.get("role").toString();

        Optional<User> user = adminSrv.findById(id);

        if( user.isPresent() ) {
            User getUser = user.get();
            getUser.setRole(newRole);
            authRep.save(getUser);
            return ResponseEntity.ok().build();

        }else{
            return ResponseEntity.status(HttpStatus.NOT_FOUND).build();
        }

    }

}
