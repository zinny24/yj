package com.example.grp.contr;

import com.example.grp.entity.SiteSettings;
import com.example.grp.srv.AdminSrv;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

@Controller
@RequestMapping("/admin")
public class AdminCont {

    private final AdminSrv adminSrv;

    public AdminCont(AdminSrv adminSrv) {
        this.adminSrv = adminSrv;
    }

    @GetMapping
    public String adminPage(Model model) {
        SiteSettings ss = adminSrv.getFindLatest();

        if( ss == null ) {
            ss = new SiteSettings();
        }

        model.addAttribute("siteSettings", ss);
        return "admin/admin";
    }

    @PostMapping("/save-site")
    public ResponseEntity<String> saveSite(
            @RequestBody SiteSettings siteSettings) {


        SiteSettings ss = adminSrv.findLatest()
                .map(existing -> {
                    existing.setTitle(  siteSettings.getTitle() );
                    existing.setMenu(  siteSettings.getMenu() );
                    existing.setMenuEng(  siteSettings.getMenuEng() );
                    existing.setIntro(  siteSettings.getIntro() );
                    return existing;

                }).orElse(siteSettings);

            adminSrv.siteSave(ss);
        return ResponseEntity.ok("success");
    }

}
