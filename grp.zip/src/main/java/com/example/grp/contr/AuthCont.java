package com.example.grp.contr;

import com.example.grp.entity.User;
import com.example.grp.srv.AuthSrv;
import jakarta.servlet.http.HttpSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
public class AuthCont {

    @Autowired
    private AuthSrv authSrv;

    @GetMapping("/register")
    public String registerForm() {
        return "register";
    }

    @PostMapping("/register")
    public String register(@RequestParam String userid,@RequestParam String passwd,@RequestParam String username,@RequestParam String role,Model model) {
        try {
            authSrv.register(userid, passwd, username, role);
            return "redirect:/";

        }catch(RuntimeException re){
            model.addAttribute("registerError", "사용할 수 없는 아이디입니다.");
            return "register";
        }
    }

    @GetMapping("/login")
    public String loginForm() {
        return "login";
    }


    @PostMapping("/login")
    public String login(
            @RequestParam String userid,
            @RequestParam String passwd,
            HttpSession session,
            Model model) {

        User u = authSrv.login(userid, passwd);

        if( u != null ) {
            session.setAttribute("loginUser", u);
            return "redirect:/";
        }else{
            model.addAttribute("loginError", "아이디 또는 비밀번호가 틀렸습니다.");
            return "login";

        }

    }

    @GetMapping("/logout")
    public String logout(HttpSession session) {
        session.invalidate();
        return "redirect:/login";
    }
}
