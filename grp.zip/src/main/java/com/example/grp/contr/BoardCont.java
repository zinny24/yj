package com.example.grp.contr;

import com.example.grp.entity.Board;
import com.example.grp.entity.User;
import com.example.grp.srv.BoardSrv;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

@Controller
public class BoardCont {

    @Autowired
    private BoardSrv boardSrv;

    @GetMapping("/board/write")
    public String boardWrite() {
        return "board/write";
    }

    @PostMapping("/board")
    public String board(
            @ModelAttribute Board board,
            @SessionAttribute(name="loginUser", required = false) User user,
            @RequestParam(value="files", required = false) MultipartFile[] files) {

        if( user == null ) {
            return "redirect:/login";
        }

        //로그인을 한 상태라면 현재 로그인 한 사람의 이름을
        // 게시물 작성자로 사용
        board.setWriter(user.getUsername());
        
        board.setParent(null); //새 글작성시에는 조인할 내용이 없으므로
        
        //첨부파일이 존재하는지 여부에 따라
        if(files != null & files.length > 0) {
            //파일도 같이 저장하는 코드
        }else{
            //파일을 빈 배열로 처리
        }

        return null;

    }


}
