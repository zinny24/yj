package com.example.grp.contr;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class SiteCont {

    @GetMapping("/")
    public String home() {
        return "site/home";
    }

    @GetMapping("/company")
    public String company() {
        return "site/company";
    }

    @GetMapping("/intro")
    public String intro() {
        return "site/intro";
    }

    @GetMapping("/contact")
    public String contact() {
        return "site/contact";
    }

}
