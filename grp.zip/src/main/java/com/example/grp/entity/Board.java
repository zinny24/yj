package com.example.grp.entity;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.hibernate.annotations.CreationTimestamp;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

@Entity
@Getter
@Setter
@NoArgsConstructor
public class Board {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String title;

    private String writer;

    private String content;

    @CreationTimestamp
    private LocalDateTime createAt;

    private Integer groupId = 0;
    private Integer step = 0;
    private Integer depth = 0;

    //답변형 데이터 연결
    @ManyToOne
    @JoinColumn(name="parent_id")
    private Board parent;

    @ElementCollection
    @CollectionTable(name="board_attachments",
            joinColumns = @JoinColumn(name="board_id"))
    @Column(name="attachment")
    private List<String> attachments = new ArrayList<>();


    public void setDefaultValues() {
        if( this.step == null) {
            this.step = 0;
        }

        if( this.depth == null ) {
            this.depth = 0;
        }
    }
}
