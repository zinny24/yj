package com.example.grp.rep;

import com.example.grp.entity.SiteSettings;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import java.util.*;

@Repository
public interface AdminRep extends JpaRepository<SiteSettings, Long> {
    Optional<SiteSettings> findFirstByOrderByIdDesc();
}
