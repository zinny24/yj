package com.example.grp.rep;

import com.example.grp.entity.Board;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface BoardRep extends JpaRepository<Board, Long> {

    @Query("SELECT * FROM article ORDER BY groupId DESC, step asc")
    List<Board> findAllByOrderByGroupIdDescStepAsc();

    //원본글을 등록할 때 필요한 최대값
    @Query("SELECT MAX(groupId) FROM board")
    Integer findMaxGroupId();

}
