package com.example.grp.srv;

import com.example.grp.entity.SiteSettings;
import com.example.grp.rep.AdminRep;
import jakarta.transaction.Transactional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Optional;

@Service
public class AdminSrv {

    private final AdminRep adminRep;

    public AdminSrv(AdminRep adminRep) {
        this.adminRep = adminRep;
    }

    @Transactional
    public void siteSave(SiteSettings siteSettings) { //사이트정보 처음 입력
        adminRep.save(siteSettings);
    }

    public Optional<SiteSettings> findLatest() { //사이트정보 수정
        return adminRep.findFirstByOrderByIdDesc();
    }

    @Transactional
    public SiteSettings getFindLatest() {
        return adminRep.findFirstByOrderByIdDesc().orElse(null);
    }


}
