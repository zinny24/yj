package com.example.grp.srv;

import com.example.grp.entity.User;
import com.example.grp.rep.AuthRep;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class AuthSrv {

    @Autowired
    private AuthRep authRep;

    public void register(String userid, String passwd, String username, String role) {

        if( authRep.findByUserid(userid).isPresent() ) {
            throw new RuntimeException("이미 존재하는 사용자 아이디입니다.");
        }

        //사용할 수는 사용자 정보
        User user = new User();
        user.setUserid(userid);
        user.setPasswd(passwd);
        user.setUsername(username);
        user.setRole(role);

        authRep.save(user);
    }

    public User login(String userid, String passwd) {
        return authRep.findByUserid(userid).filter(
                user -> user.getPasswd().equals(passwd))
                .orElse(null);
    }
}
