package com.example.grp.srv;

import com.example.grp.entity.Board;
import com.example.grp.rep.BoardRep;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

@Service
public class BoardSrv {

    @Value("${file.upload.dir}")
    private String uploadDir;

    @Autowired
    private BoardRep boardRep;

    //게시물 저장 처리
    public void writePost(Board board, MultipartFile[] files) {

        if( board.getGroupId() == 0 ) {
            Integer maxGroupId = boardRep.findMaxGroupId();
            board.setGroupId(  maxGroupId == null ? 1 : maxGroupId + 1   );
        }

        board.setDefaultValues();

        //첨부파일은 내일

        boardRep.save(board);

    }

}
