use grp;

create table site_settings(
site_id int not null auto_increment,
site_title varchar(30),
site_menu varchar(60),
site_menu_eng varchar(30),
site_intro varchar(100),
primary key(site_id)
);

insert into site_settings
(site_title, site_menu, site_menu_eng, site_intro)
values('양정인력개발',
'홈,회사소개, 부서소개,사이트맵', 'home,company,intro,contact',
'웹사이트 상대에 설명 글');