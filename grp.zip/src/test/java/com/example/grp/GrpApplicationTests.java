package com.example.grp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GrpApplicationTests {

	@Test
	void contextLoads() {
	}

}
