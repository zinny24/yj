package com.example.multi.controller;

import com.example.multi.entity.BoardManager;
import com.example.multi.repository.BoardManagerRepository;
import com.example.multi.service.BoardManagerService;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

@Controller
public class BoardController {

    private final BoardManagerService boardService;
    private final BoardManagerRepository boardRepo;
    private final JdbcTemplate jdbcTemplate;

    /*****************************************신경쓰지 말기*****************************************/
    public BoardController(BoardManagerService boardService, BoardManagerRepository boardRepo, JdbcTemplate jdbcTemplate) {
        this.boardService = boardService;
        this.boardRepo = boardRepo;
        this.jdbcTemplate = jdbcTemplate;
    }
    /***************************************************************************************/

    @GetMapping("/")
    public String home(Model model) {
        List<BoardManager> boards = boardRepo.findAll();
        model.addAttribute("boards", boards);
        return "home";
    }

    @GetMapping("/board/{boardCode}")
    public String viewBoard(@PathVariable String boardCode, Model model) {
        String tableName = "board_" + boardCode;
        String sql = String.format("SELECT * FROM %s ORDER BY id DESC", tableName);
        List<Map<String, Object>> posts = jdbcTemplate.queryForList(sql);

        model.addAttribute("posts", posts);
        model.addAttribute("boardCode", boardCode);
        return "board";
    }

    @PostMapping("/board/{boardCode}/post")
    public String postToBoard(@PathVariable String boardCode,
                              @RequestParam String title,
                              @RequestParam String content) {
        boardService.savePost(boardCode, title, content);
        return "redirect:/board/" + boardCode;
    }

    @GetMapping("/admin/board/create")
    public String createForm() {
        return "create_board";
    }

    @PostMapping("/admin/board/create")
    public String createBoard(@RequestParam String boardCode, @RequestParam String boardName) {
        boardService.createBoard(boardCode, boardName);
        return "redirect:/";
    }
}

