package com.example.multi.repository;


import com.example.multi.entity.BoardManager;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.Optional;

public interface BoardManagerRepository extends JpaRepository<BoardManager, Long> {
    Optional<BoardManager> findByBoardCode(String boardCode);
}

