package com.example.multi;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MultiApplicationTests {

	@Test
	void contextLoads() {
	}

}
