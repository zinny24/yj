package com.example.multi2;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Multi2Application {

	public static void main(String[] args) {
		SpringApplication.run(Multi2Application.class, args);
	}

}
