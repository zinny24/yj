package com.example.multi2.repository;


import com.example.multi2.entity.BoardManager;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.Optional;

public interface BoardManagerRepository extends JpaRepository<BoardManager, Long> {
    Optional<BoardManager> findByBoardCode(String boardCode);
}

