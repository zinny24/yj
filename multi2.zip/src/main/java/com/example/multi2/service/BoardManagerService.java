package com.example.multi2.service;


import com.example.multi2.entity.BoardManager;
import com.example.multi2.repository.BoardManagerRepository;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
public class BoardManagerService {

    private final JdbcTemplate jdbcTemplate;
    private final BoardManagerRepository boardManagerRepository;

    public BoardManagerService(JdbcTemplate jdbcTemplate, BoardManagerRepository boardManagerRepository) {
        this.jdbcTemplate = jdbcTemplate;
        this.boardManagerRepository = boardManagerRepository;
    }

    @Transactional
    public void createBoard(String boardCode, String boardName) {
        // 1. board_manager insert
        BoardManager boardManager = new BoardManager();
        boardManager.setBoardCode(boardCode);
        boardManager.setBoardName(boardName);
        boardManagerRepository.save(boardManager);

        // 2. 게시판 테이블 생성
        String tableName = "board_" + boardCode;

        String sql = String.format(
                "CREATE TABLE IF NOT EXISTS %s (" +
                        "id BIGINT AUTO_INCREMENT PRIMARY KEY, " +
                        "title VARCHAR(255), " +
                        "content TEXT, " +
                        "created_at DATETIME DEFAULT CURRENT_TIMESTAMP" +
                        ")", tableName
        );

        jdbcTemplate.execute(sql);
    }

    public void savePost(String boardCode, String title, String content) {
        String tableName = "board_" + boardCode;
        String sql = String.format("INSERT INTO %s (title, content) VALUES (?, ?)", tableName);
        jdbcTemplate.update(sql, title, content);
    }

    @Transactional
    public void deleteBoard(String boardCode) {
        // 1. 게시판 테이블 삭제
        String tableName = "board_" + boardCode;
        String dropSql = String.format("DROP TABLE IF EXISTS %s", tableName);
        jdbcTemplate.execute(dropSql);

        // 2. board_manager에서 삭제
        boardManagerRepository.findByBoardCode(boardCode).ifPresent(boardManagerRepository::delete);
    }

}
