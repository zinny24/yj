package com.example.multi3;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Multi3Application {

	public static void main(String[] args) {
		SpringApplication.run(Multi3Application.class, args);
	}

}
