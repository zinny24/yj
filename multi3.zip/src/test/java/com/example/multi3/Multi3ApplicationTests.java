package com.example.multi3;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Multi3ApplicationTests {

	@Test
	void contextLoads() {
	}

}
