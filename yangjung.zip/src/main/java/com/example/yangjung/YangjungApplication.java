package com.example.yangjung;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class YangjungApplication {

	public static void main(String[] args) {
		SpringApplication.run(YangjungApplication.class, args);
	}

}
