package com.example.yangjung.ajax;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;

import java.util.List;

@Controller
public class MultiController {

    @GetMapping("/uploads")
    public String viewMulti() {
        return "ajax/multi";
    }

    @PostMapping("/uploadFiles")
    @ResponseBody
    public String doUploadFiles(
            @RequestParam(name="files", required = false)
            List<MultipartFile> files) {

        if( files == null || files.isEmpty() ) {
            return "업로드 된 파일이 없습니다.";

        }else{
            StringBuilder sb = new StringBuilder();

            for(MultipartFile file : files) {
                sb.append("업로드 파일 : ");
                sb.append(file.getOriginalFilename());
                sb.append("업로드 완료<br>");
            }
            return sb.toString();
        }

    }

}
