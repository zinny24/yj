package com.example.yangjung.fileupload;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;

import java.util.UUID;

@Controller
public class FileUploadController {

    @GetMapping("/fileUpload")
    public String viewFileUpload() {
        return "fileUpload/fileUpload";
    }

    @PostMapping("/fileUpload")
    @ResponseBody
    public String doUploadFile(
            @RequestParam(required = false) MultipartFile file) {

        if( file == null || file.isEmpty() ) {
            return "업로드 된 파일이 없습니다.";

        }else{
            String ori = file.getOriginalFilename();
            String extension = "";

            if( ori != null && ori.contains(".") ) {
                extension = ori.substring(ori.lastIndexOf("."));

                String uniqueName = UUID.randomUUID() + extension;

                System.out.println(ori);
                System.out.println(extension);
                System.out.println(uniqueName);
            }

        }
        return "";
    }

}
